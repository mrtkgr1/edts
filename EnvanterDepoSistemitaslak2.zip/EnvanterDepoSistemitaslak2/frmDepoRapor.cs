﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EnvanterDepoSistemitaslak2
{
    public partial class frmDepoRapor : Form
    {
        public frmDepoRapor()
        {
            InitializeComponent();
        }
    }
}
